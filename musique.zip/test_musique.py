# -*- coding: utf8 -*-

""" Tests permettant de voir comment les fonctions de fonctions_musique marchent, et les problèmes à éviter """

import pygame
from pygame.locals import *
import fonctions_musique
from fonctions_musique import *


def main():
    pygame.init()
    screen = pygame.display.set_mode((150, 220))
    pygame.display.set_caption("test musique")

    # initialisation du fond
    background = pygame.Surface(screen.get_size()).convert()
    background.fill((255, 255, 255))

    # affichage de texte
    font = pygame.font.Font(None, 36)
    textDebut = font.render("Jouer", 1, (10, 10, 10))
    textposDebut = textDebut.get_rect()
    textposDebut.centerx = background.get_rect().centerx
    background.blit(textDebut, textposDebut)

    textPause = font.render("Pause", 1, (10, 10, 10))
    textposPause = textPause.get_rect()
    textposPause.centerx = background.get_rect().centerx
    textposPause.centery = 100
    background.blit(textPause, textposPause)

    textQuit = font.render("Quitter", 1, (10, 10, 10))
    textposQuit = textQuit.get_rect()
    textposQuit.centerx = background.get_rect().centerx
    textposQuit.centery = 200
    background.blit(textQuit, textposQuit)

    #musique est la musique que l'on joue, p est un entier égal à 0 si la musique ne tourne pas et 1 si elle est en train d'être jouée
    musique, p = creer_musique("mus_house1.ogg")


    screen.blit(background, (0, 0))
    pygame.display.update()

    # pour lancer la musique, on fait ceci :
    # p = commencer_musique(musique)



    done = 0
    while not done:
        for e in pygame.event.get():
            if e.type == QUIT:
                done = 1
            elif e.type == MOUSEBUTTONUP and e.button == 1:
                if textposDebut.collidepoint(e.pos):
                    # /!\ si l'on réutilise commencer_musique, la musique se duplique ! C'est ici un exemple pour montrer ce problème
                    p = commencer_musique(musique)
                elif textposPause.collidepoint(e.pos):
                    # l'appel à pause s'écrit p = pause_musique(musique, p). Cette fonction met en pause si la musique joue, et la reprend si elle est en pause
                    # il faut TOUJOURS avoir appelé commencer_musique au moins une fois avant d'appeler pause_musique
                    p = pause_musique(musique, p)
                elif textposQuit.collidepoint(e.pos):
                    done = 1


if __name__ == "__main__":
    main()


