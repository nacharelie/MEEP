# -*- coding: utf8 -*-

import pygame

def creer_musique(filename):
    "Ouvre un fichier de musique dont le nom est donné, et renvoie cette musique"
    pygame.mixer.init()
    sound = pygame.mixer.Sound(filename)

    playing = 0

    return sound, playing


def commencer_musique(sound, loops=-1, fade=0):
    """démarre ou recommence une musique
    sound : musique à jouer
    loops : nombre de répétitions, par défaut la musique se répète indéfiniment. Mettre à 0 pour ne pas répéter
    fade : temps en millisecondes pendant lequel le son augmente progressivement, pour lancer la musique en douceur. 0 par défaut"""
    sound.play(loops, fade)
    return 1


def pause_musique(sound, playing):
    "Met une musique en pause ou la reprend si elle est déjà en pause"
    if playing:
        pygame.mixer.pause()
        return 0
    else:
        pygame.mixer.unpause()
        return 1
