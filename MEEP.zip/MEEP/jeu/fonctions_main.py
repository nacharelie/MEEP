""" Module qui conient les fonctions suivantes : 
    une fonction afficheFenetre qui permet de mettre à jour l'affichage de la fenêtre
    pour les éléments statiques

    une fonction initialisationFenetreJeu pour initialiser la fenêtre de jeu avec les ventilateurs. 
    Elle retourne la liste des animations.

    une fonction getIndexElement pour récupérer l'index d'un élément. 
    Elle retourne un tableau de deux chiffres : 
        le tableau auquel appartient l'élément et la place dans ce tableau (au niveau noyau)
    une fonction majAnimationsVentilateur qui met à jour le ventilateur au niveau de la frame
    lorsqu'il est cliqué (appel à afficheFenetre)

    une fonction majAnimationsHelice qui met à jour les hélices

Pour utiliser le module indiquer :
import fonctions_main
from fonctions_main import *
Le module importe pour lui-même g_class,fonctions_base
"""
import g_class
from g_class import *

import fonctions_base
from fonctions_base import *
def lancer_fenetre():
#Données
    i = 0
    width = 1024
    height = 700
    fin_jeu = False
    fin_partie = False
    partiePerdu = False
    liste_fichiers = [1,2,3,4,5]

    while not fin_jeu:
        #Création de la grille (noyau)
        grille = creer_grille(liste_fichiers[i])
        nblignes = len(grille)

        #Création du plateau (graphique)
        plateau = Plateau(width,height,nblignes,"../images/background.png") #genere le plateau + affiche
        fond = plateau.grille("Niveau "+str(i+1)+" / "+str(len(liste_fichiers)))
        listeAnims = initialisationFenetreJeu(nblignes,grille,plateau)
        mise_a_jour_grille(grille)
        fin_partie = est_gagnante(grille)

        while not fin_partie:
            for event in pygame.event.get():
                fin_partie = est_gagnante(grille)
                if event.type ==QUIT:
                    fin_jeu = True
                    fin_partie = True
                    partiePerdu = True
                if event.type == MOUSEBUTTONDOWN and event.button == 1:
                    sourisX,sourisY=  event.pos
                    if sourisX<=824 and sourisY<=768:
                        index = getIndexElement(sourisX,sourisY,plateau.tailleGrille,height,nblignes)
                        mise_a_jour_elem(grille,index)
                        mise_a_jour_grille(grille)
                        majAnimationsVentilateur(grille,listeAnims,plateau,index,fond)
                #boucle pour les helices qui tournent
            majAnimationsHelice(grille,listeAnims,plateau,fond)
        if i==len(liste_fichiers)-1:
            fin_jeu = True
        else:
            i = i+1
    return partiePerdu

def fenetre_fin():
    continuer = 1
    screen = pygame.display.set_mode((250, 500))
    img = pygame.image.load("../images/fin_jeu.png").convert()
    screen.blit(img,(0,0))
    pygame.display.set_icon(pygame.image.load("../images/accueil/icon.png"))
    pygame.display.set_caption("Fin du jeu")
    pygame.display.flip()
    while continuer == 1:
        for event in pygame.event.get():
            if event.type ==QUIT:
                continuer = 0

def afficheFenetre(plateau,listeAnims,fond):
    for elem in listeAnims:
        plateau.fenetre.blit(elem.img,(elem.x,elem.y))
    pygame.display.flip()

def initialisationFenetreJeu(nblignes,grille,plateau):
#Création des animations
    tab_anims = []
    depX = 20
    depY = 20
    x = depX
    y = depY

    if nblignes==5:
        increX = 164
        if plateau.tailleGrilleY == 768:
            increY = 153
        else:
            increY = 140
    else:
        increX = 274
        if plateau.tailleGrilleY == 768:
            increY = 256
        else : 
            increY = 233

    for elem in grille:
        for i in range(len(elem)):
            if elem[i] == '1' or elem[i] == '2' or elem[i] == '3' or elem[i] == '4':
                tab_anims.append(animation(plateau,"../images/ventilo_"+str(plateau.nbCases)+"/frame-*.gif",x,y))
                x = x+increX
            elif elem[i] == '5':
                tab_anims.append(animation(plateau,"../images/helice_"+str(plateau.nbCases)+"/p*.png",x,y))
                x = x+increX
            elif elem[i] == 'B':
                tab_anims.append(animation(plateau,"../images/wall.png",x,y))
                x = x+increX
            else:
                tab_anims.append(animation(plateau,"../images/test.png",x,y))
                x = x+increX
        y = y+increY
        x=depX
#Mise en place de la fenêtre de départ
    for elem in tab_anims:  
        elem.update(0,plateau)
    pygame.display.flip()

#Récupération de la liste des animations
    return tab_anims 

def getIndexElement(x,y,width,height,nblignes):
    """On va identifer l'index d'un élément de la manière suivante : 
    indice_tab (y) indique le tableau dans lequel se trouve l'élément au niveau de la grille du noyau
    indice_elem (x) indique la place de l'élément dans le tableau indice_tab au niveau de la grille du noyau
    """
    index = []
    borne = 0
    i = 0
    j = 0
    borneX = width//nblignes
    borneY = height//nblignes
    while i<nblignes :
        if x>borne and x<borneX:
            indice_elem = i
        i = i+1
        borne = borneX
        borneX = borneX+(width//nblignes)

    borne = 0
    while j<nblignes:
        if y>borne and y<borneY:
            indice_tab = j
        j = j+1
        borne = borneY
        borneY = borneY+(height//nblignes)
    index.append(indice_tab)
    index.append(indice_elem)
    return index

def majAnimationsVentilateur(grille,listeAnims,plateau,index,fond):
    """Mise à jour des ventilateurs et on affiche à nouveau la fenêtre
    """ 
    elem = grille[index[0]][index[1]]
    if elem in ['1','2','3','4']:
        indice = index[0]*plateau.nbCases+index[1]
        listeAnims[indice].majVentilateur() #met à jour la frame en fonction du clic

def majAnimationsHelice(grille,listeAnims,plateau,fond):
    """Arrêt de l'animation des hélices qui n'ont plus de vent et
        retourne la liste des hélices à animer
    """
    nb = 0
    i=0
    listeTemp = []
    for elem in grille:
        for i in range(plateau.nbCases):
            indice = nb*plateau.nbCases+i
            if elem[i] == '5':
                listeTemp.append(listeAnims[indice])
            elif elem[i] == '6':
                listeAnims[indice].update(1,plateau)
        nb = nb+1
    plateau.fenetre.blit(fond,(0,0))
    afficheFenetre(plateau,listeAnims,plateau.fond)
    
    












    
