# -*- coding: utf8 -*-

import pygame
from pygame.locals import *

import fonctions_main
from fonctions_main import *

""" Pour changer les crédits et les règles, il suffit de remplacer les images "credits.png" et "regles.png" 
Pour rendre le tout plus joli, on peut décorer "credits.png", "regles.png" et "accueil.png". """

def afficher_menu():
    screen = pygame.display.set_mode((250, 500))
    pygame.display.set_caption("Une nouvelle air")
    pygame.display.set_icon(pygame.image.load("../images/accueil/icon.png"))

    # initialisation du fond
    background = pygame.Surface(screen.get_size()).convert()
    background.blit(pygame.image.load("../images/accueil/accueil.png").convert(), (0, 0))

    # affichage de texte
    font = pygame.font.Font(None, 36)

    textTitre = font.render("Une nouvelle air", 1, (10, 10, 10))
    textposTitre = textTitre.get_rect()
    textposTitre.centerx = background.get_rect().centerx
    textposTitre.centery = 50
    background.blit(textTitre, textposTitre)

    textDebut = font.render("Jouer", 1, (10, 10, 10))
    textposDebut = textDebut.get_rect()
    textposDebut.centerx = background.get_rect().centerx
    textposDebut.centery = 150
    background.blit(textDebut, textposDebut)

    textRegles = font.render("Règles", 1, (10, 10, 10))
    textposRegles = textRegles.get_rect()
    textposRegles.centerx = background.get_rect().centerx
    textposRegles.centery = 300
    background.blit(textRegles, textposRegles)

    textCred = font.render("Crédits", 1, (10, 10, 10))
    textposCred = textCred.get_rect()
    textposCred.centerx = background.get_rect().centerx
    textposCred.centery = 450
    background.blit(textCred, textposCred)

    screen.blit(background, (0, 0))
    pygame.display.update()

    return textposDebut, textposRegles, textposCred


def afficher_regles():
    screen = pygame.display.set_mode((250, 500))

    background = pygame.Surface(screen.get_size()).convert()
    background.fill((255, 255, 255))

    img_regles = pygame.image.load("../images/accueil/regles.png").convert()
    background.blit(img_regles, (0, 0))

    font = pygame.font.Font(None, 36)
    textRetour = font.render("Retour", 1, (10, 10, 10))
    textposRetour = textRetour.get_rect()
    textposRetour.centerx = background.get_rect().centerx
    textposRetour.centery = 420
    background.blit(textRetour, textposRetour)

    screen.blit(background, (0, 0))
    pygame.display.update()

    done = 0
    while not done:
        for e in pygame.event.get():
            if e.type == QUIT:
                done = 1
            elif e.type == MOUSEBUTTONUP and e.button == 1:
                if textposRetour.collidepoint(e.pos):
                    # retour au menu
                    done = 1


def afficher_credits():
    screen = pygame.display.set_mode((250, 500))

    background = pygame.Surface(screen.get_size()).convert()
    background.fill((255, 255, 255))

    img_regles = pygame.image.load("../images/accueil/credits.png").convert()
    background.blit(img_regles, (0, 0))

    font = pygame.font.Font(None, 36)
    textRetour = font.render("Retour", 1, (10, 10, 10))
    textposRetour = textRetour.get_rect()
    textposRetour.centerx = background.get_rect().centerx
    textposRetour.centery = 420
    background.blit(textRetour, textposRetour)

    screen.blit(background, (0, 0))
    pygame.display.update()

    done = 0
    while not done:
        for e in pygame.event.get():
            if e.type == QUIT:
                done = 1
            elif e.type == MOUSEBUTTONUP and e.button == 1:
                if textposRetour.collidepoint(e.pos):
                    # retour au menu
                    done = 1


def main():
    pygame.init()
    
    textposDebut, textposRegles, textposCred = afficher_menu()

    done = 0
    lancer_jeu = 0
    while not done:
        for e in pygame.event.get():
            if e.type == QUIT:
                done = 1
            elif e.type == MOUSEBUTTONUP and e.button == 1:
                if textposDebut.collidepoint(e.pos):
                    done = 1
                    lancer_jeu = 1
                elif textposRegles.collidepoint(e.pos):
                    afficher_regles()
                    afficher_menu()
                elif textposCred.collidepoint(e.pos):
                    afficher_credits()
                    afficher_menu()

    if lancer_jeu ==1 :
        quitter = lancer_fenetre()

    if not quitter: 
        fenetre_fin()
    


if __name__ == "__main__":
    main()