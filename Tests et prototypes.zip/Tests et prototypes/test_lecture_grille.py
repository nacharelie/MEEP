# -*- coding: utf8 -*-

""" Test pour lire un fichier de niveau et l'afficher en mode texte """

# ouverture du fichier de niveau
f = open("grille1.niv", "r")

# lecture des deux lignes (les variables sont des strings terminées par \n)
taille_grille = f.readline()
pattern = f.readline()

# on ferme le fichier car on en a plus besoin
f.close()

# la string qui contient la taille de la grille est convertie en un tableau de deux entiers, largeur et longueur
dimensions = taille_grille.split(" ")[:2]
dimensions[0], dimensions[1] = int(dimensions[0]), int(dimensions[1])
taille_grille = dimensions[0] * dimensions[1]

# préparation de la grille textuelle
grille = []

# boucle : on itère sur chaque élément de la grille pour obtenir un tableau qui représente la grille
for i in range(taille_grille):
    grille.append(pattern[i])

    if (i + 1) % dimensions[0] == 0:
        grille.append("\n")

# on rend ça lisible et joli, puis on affiche
print(grille)
grille = "".join(grille)[:-1]
print(grille)