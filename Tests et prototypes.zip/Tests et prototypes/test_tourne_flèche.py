# -*- coding: utf8 -*-

""" Montre comment faire tourner une image lorsqu'on clique dessus
Dans le jeu final, les ventilateurs devront faire pareil """

# imports utiles
import pygame
from pygame.locals import *

# constantes
NOIR = (0, 0, 0)
WINSIZE = (400, 400)
DIRECTIONS = ["haut", "droite", "bas", "gauche"]


def init_fleche():
    "charge l'image de la flèche"
    img = pygame.image.load("flèche.png").convert()
    return img


def rotate_fleche(img, orientation):
    "fait tourner l'image passée en paramètre d'un angle égal à orientation"
    img = pygame.transform.rotate(img, orientation)
    return img


def main():
    "fonction principale"

    # création de la fenêtre
    pygame.init()
    screen = pygame.display.set_mode(WINSIZE)
    pygame.display.set_caption("Test flèche")

    # remplissage de la fenêtre
    screen.fill(NOIR)
    fleche = init_fleche()
    fleche = rotate_fleche(fleche, 90)
    orientation_fleche = 0
    print("Orientation : " + DIRECTIONS[orientation_fleche])
    fleche_rec = fleche.get_rect()
    screen.blit(fleche, fleche_rec)
    pygame.display.update()

    done = 0

    while not done:
        screen.fill(NOIR)
        screen.blit(fleche, fleche_rec)
        pygame.display.update()

        for e in pygame.event.get():

            if e.type == QUIT:
                done = 1

            # si l'événement est un clic
            elif e.type == MOUSEBUTTONUP:
                # si le clic est un clic gauche et que le clic touche le rectangle de l'image
                if e.button == 1 and fleche_rec.collidepoint(e.pos):
                    fleche = rotate_fleche(fleche, -90)
                    orientation_fleche += 1
                    orientation_fleche = orientation_fleche % 4
                    print("Orientation : " + DIRECTIONS[orientation_fleche])
                    fleche_rec = fleche.get_rect()


if __name__ == "__main__":
    main()

