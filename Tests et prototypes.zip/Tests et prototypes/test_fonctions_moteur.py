# -*- coding: utf8 -*-

""" tests des fonctions pour savoir si une grille est gagnante, et pour mettre à jour une grille. """

import fonctions_base
from fonctions_base import *


def test_ouv_grille():
    grille = creer_grille(1)
    print(grille)
    # attendu : [['5', 'X', '1', '5'], ['5', 'X', '2', 'X'], ['1', '5', '5', '4'], ['X', '3', '5', '5']]
    grille = creer_grille(2)
    print(grille)
    # attendu : [['1', '5', '5', '3', '5'], ['5', '5', '3', '5', '5'], ['5', '2', '1', 'X', '5'], ['4', '1', '5', '5', 'B']]


def test_est_gagnante():
    grille_perdante = [["2", "6", "6", "6"], ["3", "X", "3", "X"], ["6", "4", "6", "5"], ["6", "B", "6", "X"]]
    print(est_gagnante(grille_perdante))
    # attendu : False

    grille_gagnante = [["2", "6", "6", "6"], ["3", "X", "3", "X"], ["6", "2", "6", "6"], ["6", "B", "6", "X"]]
    print(est_gagnante(grille_gagnante))
    # attendu : True


def test_maj():
    grille = creer_grille(3)
    print(grille)
    grille = mise_a_jour_grille(grille)
    print(grille)
    # attendu : [['6', 'X', '1', '5'], ['6', 'X', '2', 'X'], ['1', '6', '6', '4'], ['X', '3', '5', '5']]


def main():
    test_ouv_grille()
    test_est_gagnante()
    test_maj()


if __name__ == "__main__":
    main()