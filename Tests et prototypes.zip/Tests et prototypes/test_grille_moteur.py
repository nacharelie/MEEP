# -*- coding: utf8 -*-

""" Tests pour lire un fichier de niveau et le transformer en grille 2D """

# ouverture du fichier de niveau
f = open("grille2.niv", "r")

# lecture des deux lignes (les variables sont des strings terminées par \n)
taille_grille = f.readline()
pattern = f.readline()

# on ferme le fichier car on en a plus besoin
f.close()

# la string qui contient la taille de la grille est convertie en un tableau de deux entiers, largeur et longueur
dimensions = taille_grille.split(" ")[:2]
dimensions[0], dimensions[1] = int(dimensions[0]), int(dimensions[1])
taille_grille = dimensions[0] * dimensions[1]

# préparation de la grille
grille = [[]]
j = 0

# boucle : on itère sur chaque élément de la grille pour obtenir un tableau bidimensionnelle qui représente la grille
for i in range(taille_grille):
    grille[j].append(pattern[i])

    if (i + 1) % dimensions[0] == 0 and (i + 1) != taille_grille:
        grille.append([])
        j += 1

print(grille)